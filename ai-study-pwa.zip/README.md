# AI Study (PWA)

Ye installable ऐप है: फोन पर होम-स्क्रीन पर आता है और एक बार खुलने के बाद बिना इंटरनेट भी चलता है।

## फोन से चलाने के 5 कदम (GitHub Pages, मुफ़्त)
1. github.com पर अकाउंट बनाएँ, नया public repository बनाएँ (नाम: ai-study).
2. Add file > Upload files: इस फोल्डर की सभी फाइलें (index.html, manifest.json, sw.js, icon-192.png, icon-512.png) डालें, Commit करें।
3. Settings > Pages > Branch: main, Folder: /root > Save.
4. 1-2 मिनट बाद आपका लिंक बनेगा: https://<आपका-नाम>.github.io/ai-study/
5. Chrome में वह लिंक खोलें > ⋮ मेन्यू > Add to Home screen / Install app.

## अभी क्या काम करता है
होम, ट्रैक (कक्षा 1-12 और परीक्षाएँ), स्वाइप लेसन, लॉन्ग वीडियो, क्विज़, XP, ऐप के अंदर डाउनलोड, शेयर, हिंदी आवाज़।

## अगला चरण
- AI लेसन और Ask AI के लिए छोटा सर्वर (API key सर्वर पर छिपी रहे)
- लेसन का कंटेंट index.html से निकालकर अलग lessons.json फाइलों में
- लॉगिन, ताकि फोन बदलने पर भी प्रोग्रेस बनी रहे
